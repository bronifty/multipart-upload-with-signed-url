export type MPUType = {
  profile: string;
  bucket: string;
  key: string;
  uploadId: string;
};
